
/**
 * @name POS_AI.cpp
 *   Class for POS Weapon Artificial Intelligence.
 *
 * @Author:          Allan
 * @date:   28 December 17
 * @version:          0.00
 */



/* notes for this ai class...
 *
    tower 'see' distance = AttrProximityRange  250000


*/

