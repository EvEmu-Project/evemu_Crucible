
 /**
  * @name DungeonEditor.h
  *     Dungeon editor system for EVEmu
  *
  * @Author:        Allan
  * @date:          12 December 2018
  *
  */


#ifndef _EVEMU_DUNGEON_EDITOR_H
#define _EVEMU_DUNGEON_EDITOR_H

#include "../system/cosmicMgrs/DungeonMgr.h"


class DungeonEditor {
public:
    DungeonEditor()                                     { /* do nothing here */ }
    ~DungeonEditor()                                     { /* do nothing here */ }



protected:

private:

};







#endif  // _EVEMU_DUNGEON_EDITOR_H