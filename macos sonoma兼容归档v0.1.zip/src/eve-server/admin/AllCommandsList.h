//no macroguard on purpose
//if you add a new command file, you only need to add it here

#include "admin/GMCommands.h"
// #include "admin/MiningCommands.h"
#include "admin/SystemCommands.h"

#include "admin/debug_commands.h"

//clean up macros
#undef COMMAND







