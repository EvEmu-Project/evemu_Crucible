



/*
            ContractAuctionBid = 63,     // *Contract ID
            ContractAuctionBidRefund = 64,     // *Contract ID
            ContractCollateral = 65,
            ContractRewardRefund = 66,
            ContractAuctionSold = 67,
            ContractReward = 68,
            ContractCollateralRefund = 69,
            ContractCollateralPayout = 70,
            ContractPrice = 71,     // *Contract ID
            ContractBrokersFee = 72,     // *Contract ID
            ContractSalesTax = 73,     // *Contract ID
            ContractDeposit = 74,     // *Contract ID
            ContractDepositSalesTax = 75,
            ContractAuctionBidCorp = 77,
            ContractCollateralCorp = 78,
            ContractPriceCorp = 79,     // *Contract ID
            ContractBrokersFeeCorp = 80,     // *Contract ID
            ContractDepositCorp = 81,     // *Contract ID
            ContractDepositRefund = 82,     // *Contract ID
            ContractRewardAdded = 83,
            ContractRewardAddedCorp = 84,
            ContractReversal = 102,
            */