# Container Scripts
Author: James

This directory contains scripts that are used by the EVEmu docker container.