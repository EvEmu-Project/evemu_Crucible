# Configuration Files
This directory contains configuration files which are copied to the etc/ directory during a `make install` action.